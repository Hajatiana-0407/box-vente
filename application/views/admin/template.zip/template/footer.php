<script src="<?php echo Myurl('public/js/jquery.min.js'); ?>"></script>
<script src="<?php echo Myurl('public/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo Myurl('public/js/all.js') ?>"></script>
<script src="<?php echo Myurl('public/helper/Actions.js') ?>"></script>
<script src="<?php echo Myurl('public/helper/updater.js') ?>"></script>

<!-- Auto-complet -->
<script src="<?= Myurl('public/auto_complete/js/autocomplete/bootstrap.5.2.3.no.dropdown.js') ?>"></script>
<script src="<?= Myurl('public/auto_complete/js/autocomplete/dropdown.min.js') ?>"></script>
<script src="<?= Myurl('public/auto_complete/js/autocomplete/form.min.js') ?>"></script>
<script src="<?= Myurl('public/auto_complete/js/autocomplete/transition.min.js') ?>"></script>
<!-- Auto-complet -->

<script src="<?php echo Myurl('public/helper/Url.js') ?>"></script>
<script src="<?php echo Myurl('public/js/pagination.js') ?>"></script>
<script src="<?php echo Myurl('public/js/alert.js') ?>"></script>
<script src="<?php echo Myurl('public/js/side.js') ?>"></script>
<script src="<?php echo Myurl('public/js/theme.js') ?>"></script>
<script src="<?php echo Myurl('public/js/') . $js; ?>"></script>
</body>
</html>